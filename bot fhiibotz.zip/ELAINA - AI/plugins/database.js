import fs from 'fs'
import moment from 'moment-timezone'

let handler = async (m, { usedPrefix, command, conn, text }) => {
  let mentionedJid = [m.sender]
let name = conn.getName(m.sender)
let rapikz = { key : {
           participant : '0@s.whatsapp.net'
                        },
       message: {
                    locationMessage: {
                    name: 'Japan`s',
                    jpegThumbnail: fs.readFileSync('./thumbnail.jpg')
                          }
                        }
                      }
    let totalreg = Object.keys(global.db.data.users).length
    let rtotalreg = Object.values(global.db.data.users).filter(user => user.registered == true).length
    let kon = `*Database Saat Ini ${totalreg} User*\n*Terdaftar Saat Ini ${rtotalreg} User*`
let loadd = [
    'WELL',
    'WELLCOME',
    'WELLCOME TO',
    'WELLCOME TO FHII',
    'WELLCOME TO FHIIBOTZ',
    'WELLCOME TO FHIIBOTZ GANTENG'
 ]

let { key } = await conn.sendMessage(m.chat, {text: '_Loading_'})//Pengalih isu

for (let i = 0; i < loadd.length; i++) {
await conn.sendMessage(m.chat, {text: loadd[i], edit: key })}
await conn.sendMessage(m.chat, {
text: kon,
contextInfo: {
externalAdReply: {
showAdAttribution: true,
title: ``,
body: 'F H I I B O T Z  M E N U',
thumbnailUrl: 'https://autoresbot.com/tmp_files/759f3d81-9539-4284-baec-84fcf96533b0.jpg',
sourceUrl: "https://wa.me/6282284163778",
mediaType: 1,
renderLargerThumbnail: true
}}}, { quoted: rapikz})
}
handler.help = ['user']
handler.tags = ['info']
handler.command = /^(pengguna|(jumlah)?database|user)$/i

export default handler
