let handler = async (m) => {

let anu =`*PM OWNER AJA, NIH NO NYA @6282284163778 SAMBIL SV YA NAMANYA RAFI*`
await m.reply(anu)
}
handler.help = ['sc','script']
handler.tags = ['info']
handler.command = /^(sc|script)$/i

export default handler