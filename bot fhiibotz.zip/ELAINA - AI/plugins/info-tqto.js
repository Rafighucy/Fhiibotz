let handler = async (m) => {

let anu =` Thanks To
-ALLAH SWT
-SAHABAT SAYA
-BAPAK SAYA
-EMAK SAYA
-KAKAK SAYA
-ABANG SAYA
-NENEK SAYA
-KAKEK SAYA
-PAMAN SAYA
-TANTE SAYA
-MASA DEPAN SAYA
-MASA LALU SAYA
-MASA MASA SAYA
-HEHEHE
-HUHUHUHU
-HIHIHIHIHIHIHI
`
await m.reply(anu)
}
handler.help = ['tqto', 'credit']
handler.tags = ['info']
handler.command = /^(tqto|credit)$/i

export default handler