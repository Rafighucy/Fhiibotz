let handler = async (m) => {

let anu =`╔═━───╍━╍╍┄ *ᴅᴏᴡɴʟᴏᴀᴅᴇʀ*
╠➺   .ᴀꜱᴜᴘᴀɴ (ⓛ)
╠➺   .ᴀɪᴏ  (ⓟ)
╠➺   .ᴀʟʟsᴏsᴍᴇᴅ <ᴜʀʟ>
╠➺   .ᴄᴀᴘᴄᴜᴛ
╠➺   .ꜰᴀᴄᴇʙᴏᴏᴋ *[ʟɪɴᴋ]*
╠➺   .ɢᴅʀɪᴠᴇ <ᴜʀʟ>
╠➺   .ɢɪᴛᴄʟᴏɴᴇ <ᴜʀʟ> (ⓛ)
╠➺   .ɪɴꜱᴛᴀɢʀᴀᴍ
╠➺   .ɪɢᴘʜᴏᴛᴏ <ᴜʀʟ>
╠➺   .ᴍᴇᴅɪᴀꜰɪʀᴇ <ᴜʀʟ>
╠➺   .ᴘɪɴᴛᴇʀᴇꜱᴛ <ᴘᴇɴᴄᴀʀɪᴀɴ> (ⓛ)
╠➺   .ᴘɪɴᴛᴇʀᴇꜱᴛɢᴇꜱᴇʀ
╠➺   .ᴘɪɴᴛɢᴇꜱ
╠➺   .ᴘʟᴀʏ (ⓛ)
╠➺   .ꜱᴏɴɢ (ⓛ)
╠➺   .ꜱꜰɪʟᴇ
╠➺   .ᴛɪᴋᴛᴏᴋɪᴍɢ / ᴛᴛɪᴍɢ <ᴜʀʟ>
╠➺   .ᴛɪᴋᴛᴏᴋ2 <ᴜʀʟ> (ⓛ)
╠➺   .ᴛɪᴋᴛᴏᴋ (ⓛ)
╠➺   .ᴛᴡɪᴛᴛᴇʀ
╠➺   .ɢɪᴍᴀɢᴇ (ⓛ)
╠➺   .ᴘɪɴᴛᴇʀᴇꜱᴛ (ⓛ)
╠➺   .ᴡᴀʟʟᴘᴀᴘᴇʀ <qᴜᴇʀʏ>
╠➺   .ɢɪᴛʜᴜʙꜱᴇᴀʀᴄʜ <ᴘᴇɴᴄᴀʀɪᴀɴ>
╠➺   .ᴘʟᴀʏᴠɪᴅᴇᴏ (ⓛ)
╠➺   .ꜱʜᴏʀᴛ <ᴜʀʟ>
╠➺   .ɪɢꜱ <ʟɪɴᴋ ꜱᴛᴏʀʏ/ʜɪɢʜʟɪɢʜᴛ>
╠➺   .ᴄᴀᴘᴄᴜᴛ <ʟɪɴᴋ ᴄᴀᴘᴄᴜᴛ>
╠➺   .ʏᴛᴍᴘ3 (ⓛ)
╠➺   .ʏᴛᴀ (ⓛ)
╠➺   .ʏᴛꜱʜᴏʀᴛꜱ (ⓛ)
╠➺   .ʏᴛᴍᴘ4 (ⓛ)
╠➺   .ʏᴛᴠ (ⓛ)
╚═─━╍╍━╍╾
`
await conn.sendMessage(m.chat, {
  text: `${anu}`,
      contextInfo: {
      externalAdReply: {
        title: 'F H I I B O T Z',
        body: 'F H I I B O T Z  M U L T I D E V I C E',
        thumbnailUrl: 'https://autoresbot.com/tmp_files/759f3d81-9539-4284-baec-84fcf96533b0.jpg',
        sourceUrl: 'https://wa.me/6282284163778',
        mediaType: 1,
        renderLargerThumbnail: true, 
      }
        }
      }, {
        quoted: m
      });
    }
handler.help = ['menudownload']
handler.tags = ['info']
handler.command = /^(menudownload)$/i

export default handler