let handler = async (m) => {

let anu =`╔═━───╍━╍╍┄ *ɢʀᴏᴜᴘ*
╠➺   .ᴄᴇᴋɪᴅ
╠➺   .ᴇɴᴀʙʟᴇᴀʙʟᴇ <ᴏᴘᴛɪᴏɴ>
╠➺   .ᴅɪꜱᴀʙʟᴇᴀʙʟᴇ <ᴏᴘᴛɪᴏɴ>
╠➺   .ᴇɴᴀʙʟᴇ
╠➺   .ᴅɪꜱᴀʙʟᴇ
╠➺   .ᴄᴇᴋᴇxᴘɪʀᴇᴅ
╠➺   .ᴀᴅᴅ @ᴜꜱᴇʀ
╠➺   .+ @ᴜꜱᴇʀ
╠➺   .ᴅᴇᴍᴏᴛᴇ @ᴛᴀɢ
╠➺   .ᴇᴠᴇɴᴛɢᴄ *[qᴜᴇꜱᴛɪᴏɴ]*
╠➺   .ɪɴꜰᴏɢʀᴜᴘ
╠➺   .ᴋɪᴄᴋ @ᴜꜱᴇʀ
╠➺   .ʟɪɴᴋɢʀᴏᴜᴘ
╠➺   .ᴍᴇᴍᴛᴏᴛᴀɢ
╠➺   .ᴘᴇɴɢᴜᴍᴜᴍᴀɴ [ᴛᴇᴋꜱ]
╠➺   .ᴀɴɴᴏᴜɴᴄᴇ [ᴛᴇᴋꜱ]
╠➺   .ʜɪᴅᴇᴛᴀɢ [ᴛᴇᴋꜱ]
╠➺   .ʜ [ᴛᴇᴋꜱ]
╠➺   .ᴘᴏʟʟ <ʜᴀʟᴏ|ᴀᴘᴀ|ᴋᴀʙᴀʀ>
╠➺   .ᴘʀᴏᴍᴏᴛᴇ @ᴛᴀɢ
╠➺   .ʀᴇᴠᴏᴋᴇ
╠➺   .ꜱᴇᴛᴘᴘɢᴄ
╠➺   .ꜱᴇᴛᴘᴘɢᴄᴘᴀɴᴊᴀɴɢ
╠➺   .ɢʀᴏᴜᴘ *ᴏᴘᴇɴ / ᴄʟᴏꜱᴇ*
╠➺   .ɢᴄꜱɪᴅᴇʀ
╠➺   .ᴛᴀɢᴀʟʟ
╠➺   .ᴛᴀɢᴍᴇ
╠➺   .ɢʀᴏᴜᴘᴛɪᴍᴇ <ᴏᴘᴇɴ/ᴄʟᴏꜱᴇ> <ɴᴜᴍʙᴇʀ>
╠➺   .ᴛᴏᴛᴀɢ
╠➺   .ᴏᴅᴇᴍᴏᴛᴇ @ᴛᴀɢ
╠➺   .ᴛᴀɢᴀᴅᴍɪɴ
╠➺   .ʟɪꜱᴛᴀᴅᴍɪɴ
╚═─━╍╍━╍╾
`
await conn.sendMessage(m.chat, {
  text: `${anu}`,
      contextInfo: {
      externalAdReply: {
        title: 'F H I I B O T Z',
        body: 'F H I I B O T Z  M U L T I D E V I C E',
        thumbnailUrl: 'https://autoresbot.com/tmp_files/759f3d81-9539-4284-baec-84fcf96533b0.jpg',
        sourceUrl: 'https://wa.me/6282284163778',
        mediaType: 1,
        renderLargerThumbnail: true, 
      }
        }
      }, {
        quoted: m
      });
    }
handler.help = ['menugroup']
handler.tags = ['info']
handler.command = /^(menugroup)$/i

export default handler