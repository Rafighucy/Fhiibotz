let handler = async (m) => {

let anu =`╔═━───╍━╍╍┄ *ɪɴꜰᴏ*
╠➺   .ᴄᴇᴋɪᴅᴄʜ 
╠➺   .ᴏᴡɴᴇʀ
╠➺   .ᴄʀᴇᴀᴛᴏʀ
╠➺   .ᴜꜱᴇʀ
╠➺   .ʙᴏᴛꜱᴛᴀᴛᴜꜱ
╠➺   .ɢᴀᴍᴇ
╠➺   .ɢᴇᴍᴘᴀ
╠➺   .ʀᴇᴘᴏʀᴛ <ᴛᴇᴋꜱ>
╠➺   .ʀᴇqᴜᴇꜱᴛ <ᴛᴇᴋꜱ>
╠➺   .ʀᴜɴᴛɪᴍᴇ
╠➺   .ꜱᴄʀɪᴘᴛ
╠➺   .ᴛᴇꜱᴛꜱᴘᴇᴇᴅ
╠➺   .ᴛqᴛᴏ
╠➺   .ᴄʀᴇᴅɪᴛ
╠➺   .ʙᴀɴɴᴇᴅʟɪꜱᴛ
╠➺   .ʟɪꜱᴛɢᴄ
╠➺   .ᴘʀᴏꜰɪʟᴇ [@ᴜꜱᴇʀ]
╠➺   .ᴘʀᴇᴍʟɪꜱᴛ [ᴀɴɢᴋᴀ]
╠➺   .ᴘʀᴏꜰɪʟᴇ (ⓛ)
╠➺   .ᴘʀᴏꜰɪʟᴇ *⧼@ᴜꜱᴇʀ⧽* (ⓛ)
╠➺   .ʀᴏʟᴇ
╠➺   .ꜱᴇʀᴠᴇʀ
╠➺   .ᴘɪɴɢ
╠➺   .ꜱᴘᴇᴇᴅ
╠➺   .ᴠᴇʀꜱɪᴏɴ
╚═─━╍╍━╍╾
╔═━───╍━╍╍┄ *ᴍᴇɴᴜ*
╠➺   .ᴍᴇɴᴜ
╚═─━╍╍━╍╾
`
await conn.sendMessage(m.chat, {
  text: `${anu}`,
      contextInfo: {
      externalAdReply: {
        title: 'F H I I B O T Z',
        body: 'F H I I B O T Z  M U L T I D E V I C E',
        thumbnailUrl: 'https://autoresbot.com/tmp_files/759f3d81-9539-4284-baec-84fcf96533b0.jpg',
        sourceUrl: 'https://wa.me/6282284163778',
        mediaType: 1,
        renderLargerThumbnail: true, 
      }
        }
      }, {
        quoted: m
      });
    }
handler.help = ['menuinfo']
handler.tags = ['info']
handler.command = /^(menuinfo)$/i

export default handler